import requests
import json
from Config import *

#Methods
def GetToken():
    header={'content-type':'application/json', 'x-api-key':apikey}
    body= { 'grantType': 'password', 'username': userId, 'password': password }
    response = requests.post(authUrl,json=body,headers=header)
    token = response.json()["bearerToken"]
    return token




