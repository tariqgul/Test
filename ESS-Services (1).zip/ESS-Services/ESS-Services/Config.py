#Constant and configurations keys
#Constants/Keys
filePath='C:/Users/wajahatali.khalid/Downloads/20Data.xlsx'
logFilePath='C:/Users/wajahatali.khalid/Desktop/ESS-Services/_logInfo.txt'

#x-api-key
apikey='53I0sSpLNIDrH9Qju30OEY:7G4KyeFAdFn6OkOFzPcUvj'
       
apiRepoId='cabb6e774a66e3aa0d94'


#Urls
baseUrl='https://visionet.essentialintelligence.com'
authUrl = baseUrl + '/api/oauth/token'
createInstanceUrl='/api/essential-utility/v3/repositories/'+apiRepoId+'/instances'
updateInstanceUrl='/api/essential-utility/v3/repositories/'+apiRepoId+'/instances/store_30_Class10021'
batchPostInstanceUrl='/api/essential-utility/v3/repositories/'+apiRepoId+'/instances/batch'
getAllClassInstanceUrl='/api/essential-utility/v3/repositories/'+apiRepoId+'/classes/Composite_Application_Provider/instances?slots=name^ea_reference'
getAllLifeCycleStatuses='/api/essential-utility/v3/repositories/'+apiRepoId+'/classes/Lifecycle_Status/instances?directinstances=true&slots=name'

#Credentials
userId='Wajahatali.Khalid@visionet.com'
password=''


