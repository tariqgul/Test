from datetime import datetime
from Config import *

currentDate = datetime.now()

def maintainLogs(info):
    with open(logFilePath, "a") as fd:
        fd.write("Date: "+str(currentDate)+ " : Response :"+info)
        
