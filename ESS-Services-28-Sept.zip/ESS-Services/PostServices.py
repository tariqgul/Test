from Auth import *
from Config import *
import requests
import pandas 
from typing import List
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
import Logs as log

#SettingUpData
sheetNames=['Applications','App Performance Measures','App Service Quality Value','Unit of Measure']
header={'content-type':'application/json', 'x-api-key':apikey, 'authorization': 'Bearer '+GetToken()}


 
#Functions
def updateBusinessDomainIdsExcell(ids):
    wb = load_workbook(filePath)                            
    df = pandas.read_excel(filePath)  
    ws = wb.active
    df =pandas.DataFrame({'ID': ids})
    rows = dataframe_to_rows(df, index=False)
    for r_idx, row in enumerate(rows, 1):
        for c_idx, value in enumerate(row, 1):
            ws.cell(row=r_idx, column=c_idx, value=value)
    wb.save(filePath)


def fetchExcelData(sheetName,headerValue,colsRange):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=headerValue,usecols=colsRange)



def createUnitOfMeasure():
    for index, row in fetchExcelData('Unit of Measure',4,'B:D').iterrows():
        instanceBody= {"className": "Unit_Of_Measure","name": row["Name"],"description": row["Description"]}
        response=requests.post(baseUrl+createInstanceUrl,json=instanceBody,headers=header)
        log.maintainLogs(response.text)          
    print("UOM")
    print(response.status_code)


def createAppServiceQualityValue():
    for index, row in fetchExcelData('App Service Quality Value',5,'B:F').iterrows():
        instanceBody= { "className": "Application_Service_Quality_Value", "name": row["Name"],
                        "description": row["Description"],"service_quality_value_score":int(row["Score"]),  
                        "service_quality_value_uom" :{"name": row["Unit of Measure"] }}
        response=requests.post(baseUrl+createInstanceUrl,json=instanceBody,headers=header)
        log.maintainLogs(response.text)           
    print("AppSQV")
    print(response.status_code)


def createApplicationPerfomanceMeasure():
    for index, row in fetchExcelData('App Performance Measures',5,'B:H').iterrows():
        instanceBody = {   "name": row["Name"],"className": "Application_Performance_Measure",
                           "description": row["Description"],"Assessment Number":row["Assessment Number"],  
                           "pm_performance_value":[{ "name": row["Performance Level"],"className": "Application_Service_Quality_Value"}],
                           "pm_measure_date":{"name":row["Date Measured"],"className":"Year","description":"this is time"},
                           "Application Measured":{"name": row["Application Measured"],"className": "Composite_Application_Provider"}        
                       }
        response=requests.post(baseUrl+createInstanceUrl,json=instanceBody,headers=header) 
        log.maintainLogs(response.text)  
    print("APM")       
    print(response.status_code)


def createApplications():
    for index, row in fetchExcelData('Applications',5,'B:J').iterrows():
        instanceBody = {  "name": row["Name"],"className": "Composite_Application_Provider",
                          "description": row["Description"],
                          "type_of_application": [{"name": row["Type"],"className": "Application_Family"}],
                          "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
                          "lifecycle_status_application_provider": {"name": row["Lifecycle Status"],"className": "Lifecycle_Status","enumeration_value": row["Lifecycle Status"]},
                          "Category of Performance Measure": [{ "name": row["Category"],"className": "Performance_Measure_Category","enumeration_value": row["Category"]}],
                          "stakeholders": [{"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Stakeholders"],"className": "Individual_Actor",
                          "actor_plays_role": [{"name": row["Stakeholders"],"className": "ACTOR_TO_ROLE_RELATION"}]}}],
                          "ap_delivery_model": {"name": row["Delivery Model"], "className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value": row["Delivery Model"]}
                        }
        response=requests.post(baseUrl+createInstanceUrl,json=instanceBody,headers=header)
        log.maintainLogs(response.text)  
    print("APP")           
    print(response.status_code)


def runScripts():
    for index in sheetNames:
        if(index=='Applications'):
            createApplications()
        elif(index=='App Performance Measures'):
            createApplicationPerfomanceMeasure()
        elif(index=='App Service Quality Value'):         
            createAppServiceQualityValue()
        elif(index=='Unit of Measure'):
            createUnitOfMeasure()
    print('Executed')



 





# res={"stakeholders": [
#         {
#             "id": "store_30_Class10072",
#             "className": "ACTOR_TO_ROLE_RELATION",
#             "act_to_role_from_actor": { "id": "store_30_Class0","name": "Tariq Gul","className": "Individual_Actor","actor_plays_role": [
#             {   "name": "Tariq Gul as Product Owner","className": "ACTOR_TO_ROLE_RELATION","act_to_role_is_primary": false,"act_to_role_from_actor": {
#                 "id": "store_30_Class0", "name": "Tariq Gul","className": "Individual_Actor"},
#                 "act_to_role_to_role": {
#                 "id": "store_30_Class4",
#                 "name": "Product Owner",
#                 "className": "Individual_Business_Role"},
#                 "relation_name": "Tariq Gul as Product Owner", "system_author_id": "huma.arshad@visionet.com","system_last_modified_datetime_iso8601": "2022-09-20T09:12:54.067Z",
#                 "system_content_quality_status": { "name": "SYS_CONTENT_REVIEWED","className": "SYS_CONTENT_QUALITY_STATUS",
#                 "enumeration_value": "Reviewed",
#                             "enumeration_sequence_number": 1
#                         },
#                         "system_creation_datetime_iso8601": "2022-09-20T09:12:54.064Z",
#                         "system_content_lifecycle_status": {
#                             "id": "essential_baseline_6.5.4_Class67",
#                             "name": "SYS_CONTENT_APPROVED",
#                             "className": "SYS_CONTENT_APPROVAL_STATUS",
#                             "enumeration_value": "Approved",
#                             "enumeration_sequence_number": 4
#                         },
#                         "system_ea_reference_instance_counter": 0,
#                         "system_is_published": true
#                     },
#                     {
#                         "id": "store_30_Class10072",
#                         "name": "Tariq Gul as Product Owner",
#                         "className": "ACTOR_TO_ROLE_RELATION",
#                         "act_to_role_is_primary": false,
#                         "act_to_role_from_actor": {
#                             "id": "store_30_Class0",
#                             "name": "Tariq Gul",
#                             "className": "Individual_Actor"
#                         },
#                         "act_to_role_to_role": {
#                             "id": "store_30_Class4",
#                             "name": "Product Owner",
#                             "className": "Individual_Business_Role"
#                         },
#                         "relation_name": "Tariq Gul as Product Owner",
#                         "system_author_id": "huma.arshad@visionet.com",
#                         "system_last_modified_datetime_iso8601": "2022-09-20T09:13:35.336Z",
#                         "system_content_quality_status": {
#                             "id": "store_55_Class0",
#                             "name": "SYS_CONTENT_REVIEWED",
#                             "className": "SYS_CONTENT_QUALITY_STATUS",
#                             "enumeration_value": "Reviewed",
#                             "enumeration_sequence_number": 1
#                         },
#                         "system_creation_datetime_iso8601": "2022-09-20T09:13:35.333Z",
#                         "system_content_lifecycle_status": {
#                             "id": "essential_baseline_6.5.4_Class67",
#                             "name": "SYS_CONTENT_APPROVED",
#                             "className": "SYS_CONTENT_APPROVAL_STATUS",
#                             "enumeration_value": "Approved",
#                             "enumeration_sequence_number": 4
#                         },
#                         "system_ea_reference_instance_counter": 0,
#                         "system_is_published": true
#                     }
#                 ],
#                 "external_to_enterprise": false,
#                 "system_author_id": "huma.arshad@visionet.com",
#                 "system_last_modified_datetime_iso8601": "2022-09-20T09:13:35.335Z",
#                 "system_content_quality_status": {
#                     "id": "store_55_Class0",
#                     "name": "SYS_CONTENT_REVIEWED",
#                     "className": "SYS_CONTENT_QUALITY_STATUS",
#                     "lifecycle_status_content_status": {
#                         "id": "essential_baseline_6.5.4_Class67",
#                         "name": "SYS_CONTENT_APPROVED",
#                         "className": "SYS_CONTENT_APPROVAL_STATUS",
#                         "enumeration_value": "Approved",
#                         "enumeration_sequence_number": 4
#                     },
#                     "progress_requires_approval": false,
#                     "enumeration_sequence_number": 1,
#                     "enumeration_value": "Reviewed",
#                     "system_author_id": "jason.powell@e-asolutions.com",
#                     "system_last_modified_datetime_iso8601": "2022-02-11T12:26:33.342Z",
#                     "system_content_lifecycle_status": {
#                         "id": "essential_baseline_6.5.4_Class67",
#                         "name": "SYS_CONTENT_APPROVED",
#                         "className": "SYS_CONTENT_APPROVAL_STATUS",
#                         "enumeration_value": "Approved",
#                         "enumeration_sequence_number": 4
#                     },
#                     "system_creation_datetime_iso8601": "2021-03-04T23:40:36.320Z",
#                     "system_is_published": true
#                 },
#                 "system_content_lifecycle_status": {
#                     "id": "essential_baseline_6.5.4_Class67",
#                     "name": "SYS_CONTENT_APPROVED",
#                     "className": "SYS_CONTENT_APPROVAL_STATUS",
#                     "progress_requires_approval": false,
#                     "enumeration_sequence_number": 4,
#                     "enumeration_value": "Approved",
#                     "description": "Hello",
#                     "system_last_modified_datetime_iso8601": "2022-02-11T12:26:34.193Z",
#                     "system_is_published": true
#                 },
#                 "system_creation_datetime_iso8601": "2022-09-19T09:25:56.446Z",
#                 "system_ea_reference_instance_counter": 0,
#                 "system_is_published": true,
#                 "externalIds": [
#                     {
#                         "sourceName": "Essential Launchpad",
#                         "id": "IA 4"
#                     }
#                 ]
#             },
#             "act_to_role_to_role": {
#                 "id": "store_30_Class4",
#                 "name": "Product Owner",
#                 "className": "Individual_Business_Role",
#                 "role_is_external": false,
#                 "bus_role_played_by_actor": [
#                     {
#                         "id": "store_30_Class10055",
#                         "name": "Tariq Gul as Product Owner",
#                         "className": "ACTOR_TO_ROLE_RELATION",
#                         "act_to_role_is_primary": false,
#                         "act_to_role_from_actor": {
#                             "id": "store_30_Class0",
#                             "name": "Tariq Gul",
#                             "className": "Individual_Actor"
#                         },
#                         "act_to_role_to_role": {
#                             "id": "store_30_Class4",
#                             "name": "Product Owner",
#                             "className": "Individual_Business_Role"
#                         },
#                         "relation_name": "Tariq Gul as Product Owner",
#                         "system_author_id": "huma.arshad@visionet.com",
#                         "system_last_modified_datetime_iso8601": "2022-09-20T09:12:54.067Z",
#                         "system_content_quality_status": {
#                             "id": "store_55_Class0",
#                             "name": "SYS_CONTENT_REVIEWED",
#                             "className": "SYS_CONTENT_QUALITY_STATUS",
#                             "enumeration_value": "Reviewed",
#                             "enumeration_sequence_number": 1
#                         },
#                         "system_creation_datetime_iso8601": "2022-09-20T09:12:54.064Z",
#                         "system_content_lifecycle_status": {
#                             "id": "essential_baseline_6.5.4_Class67",
#                             "name": "SYS_CONTENT_APPROVED",
#                             "className": "SYS_CONTENT_APPROVAL_STATUS",
#                             "enumeration_value": "Approved",
#                             "enumeration_sequence_number": 4
#                         },
#                         "system_ea_reference_instance_counter": 0,
#                         "system_is_published": true
#                     },
#                     {
#                         "id": "store_30_Class10072",
#                         "name": "Tariq Gul as Product Owner",
#                         "className": "ACTOR_TO_ROLE_RELATION",
#                         "act_to_role_is_primary": false,
#                         "act_to_role_from_actor": {
#                             "id": "store_30_Class0",
#                             "name": "Tariq Gul",
#                             "className": "Individual_Actor"
#                         },
#                         "act_to_role_to_role": {
#                             "id": "store_30_Class4",
#                             "name": "Product Owner",
#                             "className": "Individual_Business_Role"
#                         },
#                         "relation_name": "Tariq Gul as Product Owner",
#                         "system_author_id": "huma.arshad@visionet.com",
#                         "system_last_modified_datetime_iso8601": "2022-09-20T09:13:35.336Z",
#                         "system_content_quality_status": {
#                             "id": "store_55_Class0",
#                             "name": "SYS_CONTENT_REVIEWED",
#                             "className": "SYS_CONTENT_QUALITY_STATUS",
#                             "enumeration_value": "Reviewed",
#                             "enumeration_sequence_number": 1
#                         },
#                         "system_creation_datetime_iso8601": "2022-09-20T09:13:35.333Z",
#                         "system_content_lifecycle_status": {
#                             "id": "essential_baseline_6.5.4_Class67",
#                             "name": "SYS_CONTENT_APPROVED",
#                             "className": "SYS_CONTENT_APPROVAL_STATUS",
#                             "enumeration_value": "Approved",
#                             "enumeration_sequence_number": 4
#                         },
#                         "system_ea_reference_instance_counter": 0,
#                         "system_is_published": true
#                     }
#                 ],
#                 "external_to_enterprise": false,
#                 "system_author_id": "huma.arshad@visionet.com",
#                 "system_last_modified_datetime_iso8601": "2022-09-20T09:13:35.336Z",
#                 "system_content_quality_status": {
#                     "id": "store_55_Class0",
#                     "name": "SYS_CONTENT_REVIEWED",
#                     "className": "SYS_CONTENT_QUALITY_STATUS",
#                     "lifecycle_status_content_status": {
#                         "id": "essential_baseline_6.5.4_Class67",
#                         "name": "SYS_CONTENT_APPROVED",
#                         "className": "SYS_CONTENT_APPROVAL_STATUS",
#                         "enumeration_value": "Approved",
#                         "enumeration_sequence_number": 4
#                     },
#                     "progress_requires_approval": false,
#                     "enumeration_sequence_number": 1,
#                     "enumeration_value": "Reviewed",
#                     "system_author_id": "jason.powell@e-asolutions.com",
#                     "system_last_modified_datetime_iso8601": "2022-02-11T12:26:33.342Z",
#                     "system_content_lifecycle_status": {
#                         "id": "essential_baseline_6.5.4_Class67",
#                         "name": "SYS_CONTENT_APPROVED",
#                         "className": "SYS_CONTENT_APPROVAL_STATUS",
#                         "enumeration_value": "Approved",
#                         "enumeration_sequence_number": 4
#                     },
#                     "system_creation_datetime_iso8601": "2021-03-04T23:40:36.320Z",
#                     "system_is_published": true
#                 },
#                 "system_content_lifecycle_status": {
#                     "id": "essential_baseline_6.5.4_Class67",
#                     "name": "SYS_CONTENT_APPROVED",
#                     "className": "SYS_CONTENT_APPROVAL_STATUS",
#                     "progress_requires_approval": false,
#                     "enumeration_sequence_number": 4,
#                     "enumeration_value": "Approved",
#                     "description": "Hello",
#                     "system_last_modified_datetime_iso8601": "2022-02-11T12:26:34.193Z",
#                     "system_is_published": true
#                 },
#                 "system_creation_datetime_iso8601": "2022-09-19T10:36:02.011Z",
#                 "system_ea_reference_instance_counter": 0,
#                 "system_is_published": true,
#                 "externalIds": [
#                     {
#                         "sourceName": "Essential Launchpad",
#                         "id": "BR4"
#                     }
#                 ]
#             }
#         }
# }



def updateComposteApplicationProvider(instanceBody):
    response=requests.patch(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
    compostieAppId=response.json()["instances"][0]["id"]
    #compositeAppProviderIds.append(compostieAppId)




    # compositeAppBody={
    #                     "instances":[
    #                     { 
    #                         "ea_reference":row["APP_CMDB_REF/Number"], "name": row["NAME"], "className": "Composite_Application_Provider",
    #                         "description": row["Short Description"],
                        
    #                     "ap_business_criticality": {"name":  row["Business Criticality"], "className": "Business_Criticality",
    #                                                "enumeration_value": row["Business Criticality"]},
                        
    #                     "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]
    #                                           },
                        
    #                     "application_provider_purpose": [ {"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
    #                     "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
    #                     "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
    #                     "lifecycle_status_application_provider": {"name": row["Status"],"className": "Project_Lifecycle_Status","enumeration_value": row["Status"]  },
    #                     "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
    #                     "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
    #                     "stakeholders": [{"className": "Individul_Business_Role","act_to_role_from_actor": { "name": row["Domain Architect"],"className": "Individual_Actor"}},
    #                                     {"className": "Individul_Business_Role","act_to_role_from_actor":  { "name": row["Vertical Owner"],"className": "Individual_Actor"}}],
    #                                     "performance_measures_test": result}]}




    #  for index, row in fetchExcelData(sheetName,4,'B:U').iterrows():
    #     if (index>0):
    #         if(index==1):             
    #             temp.append({"id": appIds[0]})
    #             temp.append({"id": appIds[3]})
    #             temp.append({"id": appIds[7]})
    #             temp.append({"id": appIds[12]})
    #             result=json.loads( json.dumps(temp))
    #             temp.clear()
    #         if(index==2):
    #             result=None
    #             temp.append({"id": appIds[1]})
    #             temp.append({"id": appIds[4]})
    #             temp.append({"id": appIds[8]})
    #             temp.append({"id": appIds[13]})
    #             result=json.loads( json.dumps(temp))
    #             temp.clear()
    #         if(index==3):
    #             result=None
    #             temp.append({"id": appIds[2]})
    #             temp.append({"id": appIds[5]})
    #             temp.append({"id": appIds[9]})
    #             temp.append({"id": appIds[14]})
    #             result=json.loads( json.dumps(temp))
    #             temp.clear()
    #         if(index==4):
    #             result=None
    #             temp.append({"id": appIds[3]})
    #             temp.append({"id": appIds[6]})
    #             temp.append({"id": appIds[10]})
    #             temp.append({"id": appIds[15]})
    #             result=json.loads( json.dumps(temp))
    #             temp.clear()

    #         if (index>0):
    #             compositeAppBody={"instances":[
    #                         { "ea_reference":row["APP_CMDB_REF/Number"], 
    #                           "name": row["NAME"], 
    #                           "className": "Composite_Application_Provider",
    #                           "description": row["Short Description"],
    #                           "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
    #                           "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
    #                           "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
    #                           "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
    #                           "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
    #                           "lifecycle_status_application_provider": {"name": str(row["Status"]),"className": "Project_Lifecycle_Status","enumeration_value": str( row["Status"])  },
    #                           "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
    #                           "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
    #                           "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
    #                                     "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}},
    #                                     {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Vertical Owner"],"className": "Individual_Actor"},
    #                                     "act_to_role_to_role": {"name": row["Vertical Owner"],"className": "Individual_Business_Role"}}],
    #                                     "performance_measures_test": result
    #                         }]}
    #             print(len(appUniqueRefId))        
    #             if(len(appUniqueRefId)>0 and index<= len(appUniqueRefId) and appUniqueRefId[refIdCount]==row["APP_CMDB_REF/Number"]):
    #                 compositeAppBody={"instances":[
    #                         { "id": str(appUniqueRefId[refIdCount]),"ea_reference":row["APP_CMDB_REF/Number"], 
    #                           "name": row["NAME"], 
    #                           "className": "Composite_Application_Provider",
    #                           "description": row["Short Description"],
    #                           "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
    #                           "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
    #                           "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
    #                           "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
    #                           "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
    #                           "lifecycle_status_application_provider": {"name": str(row["Status"]),"className": "Project_Lifecycle_Status","enumeration_value": str( row["Status"])  },
    #                           "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
    #                           "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
    #                           "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
    #                                     "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}},
    #                                     {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Vertical Owner"],"className": "Individual_Actor"},
    #                                     "act_to_role_to_role": {"name": row["Vertical Owner"],"className": "Individual_Business_Role"}}],
    #                                     "performance_measures_test": result
    #                         }]}
    #                 updateComposteApplicationProvider(compositeAppBody)
    #                 refIdCount+=1
    #             else:
    #                 makeComposteApplicationProvider(compositeAppBody)
    # print('Application Executed')
    # updateRefrence()