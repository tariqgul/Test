from Auth import *
from Config import *
import requests
import pandas
from typing import List
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
import Logs as log
from datetime import datetime



#SettingUpData
sheetName ='Application Health'
header ={'content-type':'application/json', 'x-api-key':apikey, 'authorization': 'Bearer '+GetToken()}
appPerformanceIds = []
compositeAppProviderIds = []
appIds=[]
appSQVID=[]
appUniqueRefId=[]
appUniqueId=[]
lifeCycleIds=[]
lifeCycleNames=[]

def getColumnNames(header,columns):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=header,usecols=columns).columns


def Post_UOM_ASQV():    
    print('Startiing UOM-ASQV')
    rowData=[]
    columnNames=[] 
    AssessmentNo=[]
    AssessmentDate=[]

    #Getting assessment details
    for index, row in fetchExcelData(sheetName,None,'C').iterrows():
        if(index==0):
            AssessmentDate.append(row[2])
        if(index==1):
            AssessmentNo.append(row[2])
            break
    
    
    ts = pandas.Timestamp(AssessmentDate[0])
    date=ts.strftime('%m/%d/%Y')
    print(date)

    #Getting busiess scores and creating unit of measure and application service quality value
    for column in getColumnNames(5,'U:Y'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'U:Y').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Business',AssessmentNo[0],date)
        appSQVID.clear()
    
    #Getting Run And Operate scores and creating unit of measure and application service quality value
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'Z:AE'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'Z:AE').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Run And Operate',AssessmentNo[0],date)
        appSQVID.clear()
    
    #Getting Architecture and Engineering scores and creating unit of measure and application service quality value
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'AF:AH'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'AF:AH').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('Architecture and Engineering',AssessmentNo[0],date)
        appSQVID.clear()
    
    #Getting Architecture and Engineering scores and creating unit of measure and application service quality value
    rowData=[]
    columnNames=[]
    for column in getColumnNames(5,'AI:AP'):
        columnNames.append(column)

    for index, row in fetchExcelData(sheetName,5,'AI:AP').iterrows():
        for column in columnNames:
            rowData.append({"name": column, "className": "Application_Service_Quality_Value",
                        "service_quality_value_value":str(row[column]),
                        "service_quality_value_uom": { "name": column,"className": "Unit_Of_Measure", "enumeration_value": column}})
        result=json.loads(json.dumps(rowData))
        body={"instances":result}
        response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
        rowData.clear()    
        for p_id in response.json()['instances']:
            hay = p_id.get('id')
            appSQVID.append(hay)
        PostAPM('North Star',AssessmentNo[0],date)
        appSQVID.clear()



#Posint batch application performance measure
def PostAPM(columnName,Assessment,Date):
    print('Executing')
    temp =[]
    for id in appSQVID:
        temp.append({"id": id}) 
    result=json.loads(json.dumps(temp))
    body={ "instances": [{ "name": columnName, "Assessment Number": str(Assessment), "pm_measure_date_iso_8601": str(Date),"className": "Application_Performance_Measure", "pm_performance_value":  result  }]}
    response=requests.post(baseUrl+batchPostInstanceUrl,json=body,headers=header)
    appId=response.json()["instances"][0]["id"]
    appIds.append(appId)
    


def settingUpData():
    getAllApplicationRequest=requests.get(baseUrl+getAllClassInstanceUrl,headers=header)
    for p_id in getAllApplicationRequest.json()['instances']:
            uniqueRefId = p_id.get('ea_reference')
            uniqueId=p_id.get('id')
            appUniqueRefId.append(uniqueRefId)
            appUniqueId.append(uniqueId)

    print(getAllClassInstanceUrl)


    getAllLifeCycleStatus=requests.get(baseUrl+getAllLifeCycleStatuses,headers=header)
    print(getAllLifeCycleStatus)

    for p_id in getAllLifeCycleStatus.json()['instances']:
            lifeCycleId = p_id.get('id')
            lifeCycleName=p_id.get('name')
            lifeCycleIds.append(lifeCycleId)
            lifeCycleNames.append(lifeCycleName)
    
    print(lifeCycleNames)
    print(lifeCycleIds)

    
    temp =[]
    for index, row in fetchExcelData(sheetName,4,'B:T').iterrows():
        result=None
        isUpdate=False
        if (index>0):      
            for rowInd in range(len(appIds)):
                temp.append({"id": appIds[index-1]})
                temp.append({"id": appIds[index+3]})
                temp.append({"id": appIds[index+7]})
                temp.append({"id": appIds[index+11]})
                break
            result=json.loads( json.dumps(temp))   
            temp.clear()
            
            lifeId=None
            for lifeCycleIndex,lifeCycleName in zip(range(len(lifeCycleNames)),lifeCycleNames):
                if(lifeCycleName==row["Status"]):
                    lifeId=lifeCycleIds[lifeCycleIndex]
            

            ts = pandas.Timestamp(row["Next Assesment Date"])
            date=ts.strftime('%m/%d/%Y')

            compositeAppBody={"instances":[
                            { "ea_reference":row["APP_CMDB_REF/Number"], 
                              "name": row["NAME"], 
                              "className": "Composite_Application_Provider",
                              "description": row["Short Description"],
                              "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality", "enumeration_value": row["Business Criticality"]},
                              "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
                              "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
                              "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_value":  row["Install Type"]},
                              "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
                              "lifecycle_status_application_provider": { "id":lifeId, "className": "Lifecycle_Status"  },
                              "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
                              "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
                              "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
                                                "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}}],
                                        "next_assessment_date": str(date),
                                        "Cloud R Factor": {"name": str(row["R Factor"]),"className": "R-Factor","enumeration_value": str(row["R Factor"]) },
                                        "Current Priorities":str(row["Current Priorities"]),
                                        "performance_measures_test": result}]}
            
            for updateIdIndex,updateId in zip(range(len(appUniqueRefId)),appUniqueRefId):
                if(updateId==row["APP_CMDB_REF/Number"]):
                    isUpdate=True
                    updateCompositeAppBody={"instances":[
                            { 
                              "id":str(appUniqueId[updateIdIndex]),"ea_reference":row["APP_CMDB_REF/Number"], 
                              "name": row["NAME"], 
                              "className": "Composite_Application_Provider",
                              "description": row["Short Description"],
                              "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality","enumeration_value": row["Business Criticality"]},
                              "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
                              "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
                              "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_value":  row["Install Type"]},
                              "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
                              "lifecycle_status_application_provider": { "id":lifeId, "className": "Lifecycle_Status"  },
                              "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
                              "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
                              "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
                                              "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}}],
                                        "next_assessment_date": str(date),
                                        "Cloud R Factor": {"name": str(row["R Factor"]),"className": "R-Factor","enumeration_value": str(row["R Factor"]) },
                                        "Current Priorities":str(row["Current Priorities"]),
                                        "performance_measures_test": result}]}
            if(isUpdate==True):
                updateComposteApplicationProvider(updateCompositeAppBody)
            else:
                makeComposteApplicationProvider(compositeAppBody)
    print('Application Executed')
    updateRefrence()


def fetchExcelData(sheetName,headerValue,colsRange):
    return pandas.read_excel(filePath,sheet_name=sheetName, header=headerValue,usecols=colsRange)


def makeComposteApplicationProvider(instanceBody):
    print(instanceBody)
    print('Executing Application')
    response=requests.post(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
    compostieAppId=response.json()["instances"][0]["id"]
    compositeAppProviderIds.append(compostieAppId)
    print(response.content)


def updateComposteApplicationProvider(instanceBody):
    print(instanceBody)
    print('Updating Application')
    response=requests.patch(baseUrl+batchPostInstanceUrl,json=instanceBody,headers=header)
    compostieAppId=response.json()["instances"][0]["id"]
    compositeAppProviderIds.append(compostieAppId)
    print(response.content)



def updateRefrence():
    print('Updating Refrence')
    count = 0
    for appIndex in range(len(appIds)):
        count +=1
        for comIndex in range(len(compositeAppProviderIds)):    
            instancebody= { "id":appIds[appIndex],"className": "Application_Performance_Measure", "Application Measured": {"id": compositeAppProviderIds[count-1]}}
            response=requests.patch(baseUrl+updateInstanceUrl,json=instancebody,headers=header)
            if(count==len(compositeAppProviderIds)):
                count=0
            break    
    print('Refrence updated')




# def CheckFunc():
#     compositeAppBody=None
#     for index, row in fetchExcelData(sheetName,4,'B:T').iterrows():
#         compositeAppBody={"instances":[
#                             { "ea_reference":row["APP_CMDB_REF/Number"], 
#                               "name": row["NAME"], 
#                               "className": "Composite_Application_Provider",
#                               "description": row["Short Description"],
#                               "ap_business_criticality": {"name": row["Business Criticality"],"className": "Business_Criticality", "enumeration_value": row["Business Criticality"]},
#                               "ap_codebase_status": {"name": row["Application Type"],"className": "Codebase_Status","enumeration_value": row["Application Type"]},
#                               "application_provider_purpose": [{"name": row["Application Category"],"className": "Application_Purpose","enumeration_value": row["Application Category"]}],
#                               "ap_delivery_model":  {"name": row["Install Type"],"className": "Application_Delivery_Model","enumeration_sequence_number": 1,"enumeration_value":  row["Install Type"]},
#                               "deployments_of_application_provider": [{"name": row["Platform"],"className": "Application_Deployment","application_deployment_label": row["Platform"]}],
#                               "lifecycle_status_application_provider": { "id":"", "className": "Lifecycle_Status"  },
#                               "ap_business_owner": {"name": row["Business Owner"],"className": "Individual_Actor"},
#                               "ap_IT_owner": {"name": row["IT Application Owner"],"className": "Individual_Actor"},
#                               "stakeholders": [ {"className": "ACTOR_TO_ROLE_RELATION","act_to_role_from_actor": {"name": row["Domain Architect"],"className": "Individual_Actor"},
#                                                 "act_to_role_to_role":{"name":row["Domain Architect"],"className":"Individual_Business_Role"}}],
#                                         # "next_assessment_date": str(date),
#                                         "Cloud R Factor": {"name": str(row["R Factor"]),"className": "R-Factor","enumeration_value": str(row["R Factor"]) },
#                                         "Current Priorities":str(row["Current Priorities"]),
#                                         # "performance_measures_test": result
#                                         }]}
#     print(compositeAppBody)
    


# CheckFunc()   

Post_UOM_ASQV()
settingUpData()


    





